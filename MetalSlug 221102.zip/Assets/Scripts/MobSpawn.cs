﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MobSpawn : MonoBehaviour
{
    public GameObject Mob;

    public float SpawnRange = 5;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void FindPlayer()
    {
        Vector3 vPos = transform.position;
        Collider2D collider = Physics2D.OverlapCircle(vPos, SpawnRange, 1 << LayerMask.NameToLayer("Player"));

        if(collider && collider.CompareTag("Player"))
        {
            
        }
    }

}
