﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Opossum : MonoBehaviour
{
    public float Speed = 1;
    public float Score = 20;
    public float Site = 1;

    public bool isMove;

    public GameObject ScoreItemGO;
    public GameObject GunItemGO;

    public GameObject targetPlayer;

    public Transform targetTr;
    public Transform trRespawnPoint;
    public Transform trPatrolPoint;

    public SpriteRenderer sprite;

    float trankingSpeed = 0.8f;
    float returnSpeed = 2.5f;
    float patrolSpped = 1f;

    public enum eAIStatus
    {
        NONE = -1,
        TRACKING,
        RETURN,
        PATROL
    }

    public eAIStatus curState;

    void Start()
    {
        curState = eAIStatus.PATROL;
    }

    void Update()
    {
        targetPlayer = FindProcess(); //< 플레이어 서칭.
        UpdateState(); //< 플레이어 서칭됐을때 / 안됐을때

        MoveProcess();
    }

    public void UpdateState()
    {
        if (targetPlayer != null)
        {
            targetTr = targetPlayer.transform;
            curState = eAIStatus.TRACKING;
        }

        switch (curState)
        {
            case eAIStatus.TRACKING:
                if (targetPlayer == null)
                {
                    curState = eAIStatus.RETURN;
                    targetTr = trRespawnPoint;
                }
                else
                    Speed = trankingSpeed;
                break;
            case eAIStatus.RETURN:
                if (targetTr != null)
                {
                    Speed = returnSpeed;

                    if (!isMove)
                    {
                        curState = eAIStatus.PATROL;
                    }
                }
                else
                    targetTr = trRespawnPoint;
                break;
            case eAIStatus.PATROL:
                if (targetTr != null)
                {
                    Speed = patrolSpped;

                    if (!isMove)
                    {
                        if (targetTr.gameObject.name == trPatrolPoint.gameObject.name)
                        {
                            targetTr = trRespawnPoint;
                        }
                        else if (targetTr.gameObject.name == trRespawnPoint.gameObject.name)
                        {
                            targetTr = trPatrolPoint;
                        }
                    }
                }
                else
                    targetTr = trPatrolPoint;
                break;
        }
    }

    public void MoveProcess()
    {
        if (targetTr != null)
        {
            Vector3 vTargetPos = targetTr.position;
            Vector3 vMyPos = transform.position;
            vTargetPos.y = 0;
            vMyPos.y = 0;
            Vector3 vDist = vTargetPos - vMyPos;//위치의 차이를 이용한 거리구하기
            Vector3 vDir = vDist.normalized;//두물체사이의 방향(평준화-거리를뺀 이동량)
            float fDist = vDist.magnitude; //두물체사이의 거리(스칼라-순수이동량)

            if (fDist > Speed * Time.deltaTime)//한프레임의 이동거리보다 클때만 이동한다.
            {
                transform.position += vDir * Speed * Time.deltaTime;
                isMove = true;
            }
            else
            {
                isMove = false;
                Debug.Log("Move End");
            }

            sprite.flipX = (vTargetPos.x - vMyPos.x) > 0;
        }
    }

    public GameObject FindProcess()
    {
        Vector3 vPos = this.transform.position;
        Collider2D collider = Physics2D.OverlapCircle(vPos, Site, 1 << LayerMask.NameToLayer("Player"));

        if (collider != null)
            return collider.gameObject;
        else
            return null;
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(this.transform.position, Site);

        Gizmos.color = Color.green;
        if (trRespawnPoint) Gizmos.DrawWireSphere(trRespawnPoint.position, Time.deltaTime);

        Gizmos.color = Color.red;
        if (trPatrolPoint) Gizmos.DrawWireSphere(trPatrolPoint.position, Time.deltaTime);

        Gizmos.color = Color.blue;
        if (targetTr) Gizmos.DrawWireSphere(targetTr.position, Time.deltaTime * 2);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            //Destroy(collision.gameObject);
            collision.gameObject.SetActive(false);
            targetTr = null;

            curState = eAIStatus.RETURN;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Bullet"))
        {
            Bullet bullet = collision.gameObject.GetComponent<Bullet>();
            bullet.dynamic.Score += Score;
            Destroy(this.gameObject);
            var prefab = Random.Range(0, 2) == 0 ? ScoreItemGO : GunItemGO;
            GameObject Item = Instantiate<GameObject>(prefab, transform.position, Quaternion.identity);
            //var item = ScoreItem.GetComponent<Item>();
            //item.type = Random.Range(0, 2) == 0 ? Item.ItemType.Score : Item.ItemType.Gun;
        }
    }
}
