﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    public Vector3 vStartPos;
    public Vector3 vPos;
    public float fDist = 1;
    public Dynamic dynamic;
    // Start is called before the first frame update
    void Start()
    {
        vStartPos = this.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        vPos = this.transform.position;
        float Dist = Vector3.Distance(vStartPos, vPos);
        if(fDist < Dist)
        {
            Destroy(this.gameObject);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Monster")
        {
            Destroy(collision.gameObject);
        }
    }
}
