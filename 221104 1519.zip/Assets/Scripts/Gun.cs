﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum GunType
{
    Default,
    Heavy,
}

public class Gun : MonoBehaviour
{
    public Text bulletText;

    public int _Ammo;

    public int Ammo
    {
        get
        {
            return _Ammo;
        }
        set
        {
            _Ammo = value;
            if (curGunType == GunType.Default)
            {
                bulletText.text = "Ammo : Infinity";
            }
            else
            {
                bulletText.text = "Ammo : " + Ammo.ToString();
            }
        }
    }
    public int MaxAmmo;


    public DataBase DB;

    public GunType curGunType;

    public float moveSpeed;

    public GameObject objBullet;
    public Dynamic player;



    GunInfo curGunInfo;

    void Awake()
    {
        Change(GunType.Default);
    }

    public void Shot(Vector3 dir)
    {
        if (Ammo > 0)
        {
            Bullet CopyBullet = Instantiate(objBullet, transform.position, Quaternion.identity).GetComponent<Bullet>();
            CopyBullet.dynamic = player;
            Rigidbody2D rigidbody = CopyBullet.GetComponent<Rigidbody2D>();
            rigidbody.AddForce(dir * moveSpeed);

            if (curGunType != GunType.Default)
                Ammo--;
        }
        else
        {
            Debug.Log("총알 없음");
        }
        if (Ammo <= 0)
            Change(GunType.Default);
    }

    public void Change(GunType type)
    {
        var curGunInfo = DB.GetGunInfo(type);

        curGunType = type;
        Ammo = curGunInfo.maxAmmo;
        objBullet = curGunInfo.bulletObj;
        gameObject.GetComponent<SpriteRenderer>().sprite = curGunInfo.gunSprite;
    }
}
