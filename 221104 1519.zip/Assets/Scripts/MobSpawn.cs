﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MobSpawn : MonoBehaviour
{
    public GameObject GoMob;
    public Transform SpawnPoint;

    public float SpawnRange;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        Vector3 vPos = transform.position;
        CircleCollider2D collider2D = SpawnPoint.GetComponent<CircleCollider2D>();
        SpawnRange = collider2D.radius;

        if (collision.CompareTag("Player"))
        {
            GameObject copyMob = Instantiate(GoMob, transform.position, Quaternion.identity);
            Destroy(this.gameObject);
        }
    }

    private void OnDrawGizmos()
    {
        CircleCollider2D collider2D = SpawnPoint.GetComponent<CircleCollider2D>();
        SpawnRange = collider2D.radius;
        Gizmos.DrawWireSphere(this.transform.position, SpawnRange);
    }



}
