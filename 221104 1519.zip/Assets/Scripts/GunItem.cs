﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunItem : MonoBehaviour
{
    public SpriteRenderer sr;
    public Sprite heavySprite;
    public Sprite otherSprite;

    public GunType itemType;

    public void Init(GunType type)
    {
        itemType = type;

        switch (itemType)
        {
            case GunType.Heavy:
                sr.sprite = heavySprite;
                break;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log(gameObject.name + ".OnCollisionEnter2D:" + collision.gameObject.name);
        if (collision.gameObject.tag == "Player")
        {
            //gun.Change(Gun.Guntype.HeavyMachineGun);
            Debug.Log("충돌");
            Dynamic player = collision.gameObject.GetComponent<Dynamic>();
            player.gun.Change(itemType);
            Destroy(this.gameObject);
        }
    }
}
