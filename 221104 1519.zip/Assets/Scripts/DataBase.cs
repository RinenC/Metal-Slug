﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DataBase : MonoBehaviour
{
    public List<GunInfo> gunInfoList = new List<GunInfo>();

    public GunInfo GetGunInfo(GunType type)
    {
        return gunInfoList.Find(x => x.gunType == type);
    }
}
