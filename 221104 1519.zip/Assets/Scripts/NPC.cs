﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPC : MonoBehaviour
{
    public float speed;
    public float checkRange;
    public float score;

    public float time = 5;

    public GameObject gunitemGO;

    public SpriteRenderer sprite;

    public bool isSolve;
    public bool isMove;

    public Transform targetTr;
    public Transform respawnTr;
    public Transform patrolTr;
    public enum ENPCAIStatus
    {
        Idle,
        Patrol,
        ItemDrop,
    }

    public ENPCAIStatus curState;
    // Start is called before the first frame update
    void Awake()
    {
        curState = ENPCAIStatus.Idle;
        isSolve = false;
        speed = 1f;
        checkRange = 0.3f;
        score = 30;
    }

    // Update is called once per frame
    void Update()
    {
        FindProcess();
        UpdateStatus();
        MoveProcess();
    }

    public void UpdateStatus()
    {
        if (isSolve)
        {
            switch (curState)
            {
                case ENPCAIStatus.Patrol:
                    if (!isMove)
                    {
                        if (targetTr.gameObject.name == patrolTr.gameObject.name)
                        {
                            targetTr = respawnTr;
                        }
                        else if (targetTr.gameObject.name == respawnTr.gameObject.name)
                        {
                            targetTr = patrolTr;
                        }
                    }
                    break;
                case ENPCAIStatus.ItemDrop:
                    if (time <= 0)
                    {
                        GameObject gunItem = Instantiate(gunitemGO, transform.position, Quaternion.identity);
                        Destroy(this.gameObject);
                    }
                    else
                        time -= Time.deltaTime;
                    break;
            }
        }
    }

    public void MoveProcess()
    {
        if (isSolve)
        {
            if (curState != ENPCAIStatus.ItemDrop)
            {
                if (targetTr != null)
                {
                    Vector3 vTargetPos = targetTr.position;
                    Vector3 vMyPos = transform.position;
                    vTargetPos.y = 0;
                    vMyPos.y = 0;
                    Vector3 vDist = vTargetPos - vMyPos;//위치의 차이를 이용한 거리구하기
                    Vector3 vDir = vDist.normalized;//두물체사이의 방향(평준화-거리를뺀 이동량)
                    float fDist = vDist.magnitude; //두물체사이의 거리(스칼라-순수이동량)

                    if (fDist > speed * Time.deltaTime)//한프레임의 이동거리보다 클때만 이동한다.
                    {
                        transform.position += vDir * speed * Time.deltaTime;
                        isMove = true;
                    }
                    else
                    {
                        isMove = false;
                        Debug.Log("Move End");
                    }

                    sprite.flipX = (vTargetPos.x - vMyPos.x) < 0;
                }
            }
        }
    }

    public void FindProcess()
    {
        Vector3 vPos = this.transform.position;
        Collider2D collider = Physics2D.OverlapCircle(vPos, checkRange, 1 << LayerMask.NameToLayer("Player"));

        if (collider != null && collider.gameObject.CompareTag("Player"))
        {
            curState = ENPCAIStatus.ItemDrop;
        }
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (!isSolve)
        {
            if (collision.gameObject.CompareTag("Bullet"))
            {
                Bullet bullet = collision.gameObject.GetComponent<Bullet>();
                Destroy(collision.gameObject);
                isSolve = true;
                curState = ENPCAIStatus.Patrol;
                bullet.dynamic.Score += score;
            }
        }
    }

    public void OnDrawGizmos()
    {
        Gizmos.color = Color.green;
        Gizmos.DrawWireSphere(transform.position, checkRange);

        Gizmos.color = Color.green;
        if (respawnTr) Gizmos.DrawWireSphere(respawnTr.position, Time.deltaTime);

        Gizmos.color = Color.red;
        if (patrolTr) Gizmos.DrawWireSphere(patrolTr.position, Time.deltaTime);

        Gizmos.color = Color.blue;
        if (targetTr) Gizmos.DrawWireSphere(targetTr.position, Time.deltaTime * 2);
    }
}
