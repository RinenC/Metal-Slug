﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "GunInfo", menuName = "Scriptable Object/GunInfo", order = int.MaxValue)]
public class GunInfo : ScriptableObject
{
    public int maxAmmo;
    public GameObject bulletObj;
    public float shotDelay;
    public Sprite gunSprite;
    public Sprite itemSprite;

    public GunType gunType;
}
