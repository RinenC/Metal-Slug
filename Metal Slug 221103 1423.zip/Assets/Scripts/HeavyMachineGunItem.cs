﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeavyMachineGunItem : MonoBehaviour
{
    public Gun gun;
    void Start()
    {
        
    }

    void Update()
    {

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log(gameObject.name + ".OnCollisionEnter2D:" + collision.gameObject.name);
        if (collision.gameObject.tag == "Player")
        {
            //gun.Change(Gun.Guntype.HeavyMachineGun);
            Debug.Log("충돌");
            Destroy(this.gameObject);
        }
    }
}