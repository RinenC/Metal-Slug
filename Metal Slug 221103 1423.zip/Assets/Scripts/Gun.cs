﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour
{
    public GameObject objBullet;
    public float Power = 1;
    public Dynamic player;

    public int Ammo;
    public int MaxAmmo = 5;

    public enum Guntype
    {
        HandGun,
        HeavyMachineGun,
        RocketLauncher,
        FlameShot,
        ShotGun,
        LaserGun,
    }

    public Guntype type = Guntype.HeavyMachineGun;

    public void Shot(Vector3 dir)
    {
        if (Ammo > 0)
        {
            Bullet CopyBullet = Instantiate(objBullet, transform.position, Quaternion.identity).GetComponent<Bullet>();
            CopyBullet.dynamic = player;
            Rigidbody2D rigidbody = CopyBullet.GetComponent<Rigidbody2D>();
            rigidbody.AddForce(dir * Power);
            Ammo--;
        }
        else
            Debug.Log("총알 없음");
    }

    void Start()
    {
        Ammo = MaxAmmo;
    }

    void Update()
    {
        
    }
}
