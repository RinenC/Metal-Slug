﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dynamic : MonoBehaviour
{
    public float Score;

    public Vector3 vDir;

    public Gun gun;

    public float Speed;
    public float JumpPower;

    public bool isJump;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKey(KeyCode.LeftArrow))
        {
            transform.position += Vector3.left * Speed * Time.deltaTime;
        }

        if (Input.GetKey(KeyCode.RightArrow))
        {
            transform.position += Vector3.right * Speed * Time.deltaTime;
        }

        if(Input.GetKeyDown(KeyCode.Space))
        {
            if (isJump == false)
            {
                Rigidbody2D rigidbody = GetComponent<Rigidbody2D>();
                rigidbody.AddForce(Vector3.up * JumpPower);
                isJump = true;
            }
        }

        if(Input.GetKeyDown(KeyCode.X))
        {
            gun.Shot(vDir);
            Debug.Log($"총알 개수 : {gun.Ammo}");
        }

        if(Input.GetKeyDown(KeyCode.R))
        {
            Reload();
        }
    }

    public void Reload()
    {
        gun.Ammo = gun.MaxAmmo;
        Debug.Log($"총알 개수 : {gun.Ammo}");
        //$"{}" 형식을 문자열 보간 이라고 한다.
    }

    private void OnGUI()
    {
        GUI.Box(new Rect(0, 0, 200, 20), "Score:" + Score);
    }

    public void OnCollisionEnter2D(Collision2D collision)
    {
        isJump = false;
    }
}
