﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour
{
    public GameObject objBullet;
    public float Power = 1;
    public Dynamic dynamic;

    public int Ammo;
    public int MaxAmmo = 5;

    public enum ITEM_SORT { 
                            HMG,
                            LG,
                            FG
                          }

    public void Shot(Vector3 dir)
    {
        if (Ammo > 0)
        {
            Bullet CopyBullet = Instantiate(objBullet, transform.position, Quaternion.identity).GetComponent<Bullet>();
            CopyBullet.dynamic = dynamic;
            Rigidbody2D rigidbody = CopyBullet.GetComponent<Rigidbody2D>();
            rigidbody.AddForce(dir * Power);
            Ammo--;
        }
        else
            Debug.Log("총알 없음");
    }

    public void Change(ITEM_SORT itemtype)
    {
        switch (itemtype)
        {
            case ITEM_SORT.HMG :
                break;

        }
    }

    void Start()
    {
        Ammo = MaxAmmo;
    }

    void Update()
    {
        
    }
}
