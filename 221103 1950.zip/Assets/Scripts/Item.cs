﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    Dynamic player;
    public int Score = 10;

    public SpriteRenderer sprite;

    public enum ItemType
    {
        Score,
        Gun,
    }

    public ItemType type = ItemType.Score;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log(gameObject.name + ".OnCollisionEnter2D:" + collision.gameObject.name);
        Dynamic dynamic = collision.gameObject.GetComponent<Dynamic>();
        if (collision.gameObject.tag == "Player")
        {
            player = dynamic;
            UseItem();
        }
    }

    protected void UseItem()
    {
        switch (type)
        {
            case ItemType.Score:
                player.Score += Score;
                break;
            case ItemType.Gun:
                player.Reload();
                break;
        }

        Destroy(this.gameObject);
    }
}
