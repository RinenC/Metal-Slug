﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GunItem : MonoBehaviour
{
    public GunInfo itemGunInfo;
    void Start()
    {
        gameObject.GetComponent<SpriteRenderer>().sprite = itemGunInfo.itemSprite;
    }

    void Update()
    {

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Debug.Log(gameObject.name + ".OnCollisionEnter2D:" + collision.gameObject.name);
        if (collision.gameObject.tag == "Player")
        {
            //gun.Change(Gun.Guntype.HeavyMachineGun);
            Debug.Log("충돌");
            Destroy(this.gameObject);
            Dynamic player = collision.gameObject.GetComponent<Dynamic>();
            player.gun.Change(itemGunInfo);
        }
    }
}
