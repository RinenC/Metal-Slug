﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour
{
    public GameObject objBullet;
    public float Power = 1;
    public Dynamic player;
    [SerializeField]
    GunInfo gunInfo;

    public int Ammo;
    public int MaxAmmo;

    public void Shot(Vector3 dir)
    {
        if (Ammo > 0)
        {
            Bullet CopyBullet = Instantiate(objBullet, transform.position, Quaternion.identity).GetComponent<Bullet>();
            CopyBullet.dynamic = player;
            Rigidbody2D rigidbody = CopyBullet.GetComponent<Rigidbody2D>();
            rigidbody.AddForce(dir * Power);
            Ammo--;
        }
        else
            Debug.Log("총알 없음");
    }

    public void Change(GunInfo _gunInfo)
    {
        Ammo = _gunInfo.maxAmmo;
        objBullet = _gunInfo.bulletObj;
        gameObject.GetComponent<SpriteRenderer>().sprite = _gunInfo.gunSprite;
    }

    void Start()
    {
        Change(gunInfo);
    }

    void Update()
    {
        
    }
}
